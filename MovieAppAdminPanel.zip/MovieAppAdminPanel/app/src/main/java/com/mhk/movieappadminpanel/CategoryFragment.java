package com.mhk.movieappadminpanel;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.media.R;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class CategoryFragment extends Fragment {


    public CategoryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        FloatingActionButton floatingActionButton = view.findViewById(R.id.float_btn);
        floatingActionButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CategoryPopUP categoryPopUP = new CategoryPopUP();
                        FragmentManager fragmentManager = getFragmentManager();
                        categoryPopUP.show(fragmentManager, "show category");
                    }
                }
        );
        ListView listView = view.findViewById(R.id.category_list);
        final ArrayList<CategoryModel> categoryModels = new ArrayList<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference categoryRef = db.collection("categories");
        categoryRef.get().addOnSuccessListener(
                new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                            categoryModels.add(snapshot.toObject(CategoryModel.class));
                        }
                    }
                });
            CategoryAdapter adapter=new CategoryAdapter(categoryModels);
            listView.setAdapter(adapter);

        return view;
    }

    private class CategoryAdapter extends BaseAdapter {
        ArrayList<CategoryModel> categoryModels = new ArrayList<>();

        public CategoryAdapter(ArrayList<CategoryModel> categoryModels) {
            this.categoryModels = categoryModels;
        }


        @Override
        public int getCount() {
            return categoryModels.size();
        }

        @Override
        public Object getItem(int position) {
            return categoryModels.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater=getLayoutInflater();
            View v=inflater.inflate(R.layout.category_list,null);
            TextView categorySr=v.findViewById(R.id.category_sr);
            TextView categoryName=v.findViewById(R.id.category_name);
            categorySr.setText(String.valueOf(position+1));
            categoryName.setText(categoryModels.get(position).categoryName);
            return v;
        }
    }

}