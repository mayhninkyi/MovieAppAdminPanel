package com.mhk.movieappadminpanel;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class CategoryPopUP extends DialogFragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.category_popup,container,false);
        Button savebtn=v.findViewById(R.id.popup_save_btn);
        final EditText edt=v.findViewById(R.id.category_txt);
        savebtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CategoryModel c=new CategoryModel(edt.getText().toString());
                        FirebaseFirestore db=FirebaseFirestore.getInstance();
                        CollectionReference ref=db.collection("categories");
                        ref.add(c);
                    }
                }
        );


        return v;
    }
}
