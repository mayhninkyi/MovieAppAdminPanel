package com.mhk.movieappadminpanel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setFragment(new MoviesFragment());
        BottomNavigationView botnav=findViewById(R.id.botnav);
        botnav.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                        if(R.id.movie_ic== menuItem.getItemId()){
                            setFragment(new MoviesFragment());
                        }
                        if(R.id.series_ic== menuItem.getItemId()){
                            setFragment(new SeriesFragment());
                        }
                        if(R.id.category_ic== menuItem.getItemId()){
                            setFragment(new CategoryFragment());
                        }
                        return true;
                    }
                }
        );
    }

    public void setFragment(Fragment fra){
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fra);
        fragmentTransaction.commit();
    }
}
